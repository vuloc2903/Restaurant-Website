<!DOCTYPE html>
<html>
<head>
    <title>Vu Dinh Loc Calculator</title>
    <style>
        .calculator {
            width: 320px;
            height: 400px; 
            margin: 20px auto;
            background-color: #f7f7f7;
            border: 2px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            padding: 20px;
            background: linear-gradient(to bottom, #FFB6C1, #FF69B4); 
            color: #fff;
            text-align: center;
            font-size: 20px; 
        }

        .calculator h1 {
            font-size: 24px;
            margin: 10px 0;
            color: #FF1705;
        }

        .calculator form {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            color: #FF2903;
        }

        .calculation-row {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .calculation-row label,
        .calculation-row select {
            width: 48%;
            margin: 0;
        }

        .calculation-row select {
            width: 50%;
        }

        .calculator button[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #74575e;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            margin-top: 10px;
        }

        .calculator button[type="submit"]:hover {
            background-color: #74575e;
        }

        .result {
            font-size: 24px;
            margin: 20px 0;
            color: #FF2903;
        }

        .footer {
            font-size: 14px;
            margin-top: 20px;
            text-align: center;
        }

        .clear-button {
            background-color: #ff0000;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            padding: 10px;
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="calculator">
        <h1>Vu Dinh Loc Calculator</h1>
        <form method="post">
            <div class="calculation-row">
                <label for="num1">Number 1:</label>
                <input type="text" id="num1" name="num1" required>
            </div>

            <div class="calculation-row">
                <label for="num2">Number 2:</label>
                <input type="text" id="num2" name="num2" required>
            </div>

            <div class="calculation-row">
                <label for="operation">Operation:</label>
                <select id="operation" name="operation">
                    <option value="+">+</option>
                    <option value="-">-</option>
                    <option value="*">*</option>
                    <option value="/">/</option>
                </select>
            </div>

            <button type="submit" name="calculate">Calculate</button>
        </form>
        
        <div class="result">
            <?php
            if (isset($_POST['calculate'])) {
                $num1 = floatval($_POST['num1']);
                $num2 = floatval($_POST['num2']);
                $operation = $_POST['operation'];
                $result = 0;

                switch ($operation) {
                    case '+':
                        $result = $num1 + $num2;
                        break;
                    case '-':
                        $result = $num1 - $num2;
                        break;
                    case '*':
                        $result = $num1 * $num2;
                        break;
                    case '/':
                        if ($num2 != 0) {
                            $result = $num1 / $num2;
                        } else {
                            echo "Cannot divide by 0.";
                        }
                        break;
                    default:
                        echo "Error.";
                }

                echo 'Result: ' . $result;
            }
            ?>
        </div>

        <form method="post">
            <button type="submit" name="clearHistory" class="clear-button">Clear Result</button>
        </form>
    </div>

    <div class="footer">© Vu Dinh Loc 58229 || 2023</div>
</body>
</html>
